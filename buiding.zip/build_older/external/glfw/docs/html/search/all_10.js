var searchData=
[
  ['name_0',['name',['../monitor_guide.html#monitor_name',1,'Human-readable name'],['../input_guide.html#joystick_name',1,'Joystick name']]],
  ['name_20change_20tables_1',['Name change tables',['../moving_guide.html#moving_tables',1,'']]],
  ['names_2',['Key names',['../input_guide.html#input_key_name',1,'']]],
  ['native_20access_3',['Native access',['../group__native.html',1,'']]],
  ['native_20interface_4',['Native interface',['../internals_guide.html#internals_native',1,'']]],
  ['new_20constants_5',['New constants',['../news.html#new_constants',1,'']]],
  ['new_20features_6',['New features',['../news.html#features',1,'']]],
  ['new_20functions_7',['New functions',['../news.html#new_functions',1,'']]],
  ['new_20symbols_8',['New symbols',['../news.html#new_symbols',1,'']]],
  ['new_20types_9',['New types',['../news.html#new_types',1,'']]],
  ['news_2emd_10',['news.md',['../news_8md.html',1,'']]],
  ['notes_20for_20earlier_20versions_11',['Release notes for earlier versions',['../news.html#news_archive',1,'']]],
  ['notes_20for_20version_203_205_12',['Release notes for version 3.5',['../news.html',1,'']]]
];
